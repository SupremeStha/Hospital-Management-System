# Imports
from Admin import Admin
from Doctor import Doctor
from Patient import Patient

def main():
    """
    the main function to be ran when the program runs
    """

    # Initialising the actors
    admin = Admin('admin','123','B1 1AB') # username is 'admin', password is '123'
    doctors = [Doctor('John','Smith','Internal Med.'), Doctor('Jone','Smith','Pediatrics'), Doctor('Jone','Carlos','Cardiology')]
    patients = [Patient('Sara','Smith', 20, '07012345678','B1 234','Fever', 'Corona'), Patient('Mike','Jones', 37,'07555551234','L2 2AB','Headache', 'Migraine'), Patient('Daivd','Smith', 15, '07123456789','C1 ABC','Vomitting', 'Infection')]

    discharged_patients = []

    # keep trying to login tell the login details are correct
    while True:
        if admin.login():
            running = True # allow the program to run
            break
        else:
            print('Incorrect username or password.')

    while running:
        # print the menu
        print('Choose the operation:')
        print(' 1- Register/view/update/delete doctor')
        print(' 2- Discharge patients')
        print(' 3- View discharged patient')
        print(' 4- Assign doctor to a patient')
        print(' 5- View patient names grouped by family') 
        print(' 6- Relocate patient to new doctor')  
        print(' 7- Appointment')
        print(' 8- Patient Management')
        print(' 9- Update admin details')
        print(' 10- Management report')
        print(' 11- Management Report Diagram')
        print(' 0- Quit')

        # get the option
        op = input('Option: ')

        if op == '1':
        # 1- Register/view/update/delete doctor
         #ToDo1
          admin.doctor_management(doctors)

        elif op == '2':
            admin.view_patient(patients)

            while True:
                op = input('Do you want to discharge a patient(Y/N):').lower()

                if op == 'yes' or op == 'y':
                    #ToDo3
                    admin.discharge(patients,discharged_patients)

                elif op == 'no' or op == 'n':
                    break

                else:
                    print('Please answer by yes or no.')
        
        elif op == '3':
            admin.view_discharge(discharged_patients)

        elif op == '4':
            admin.assign_doctor_to_patient(patients, doctors)

        elif op == '5':
            admin.group_patients_by_family(patients)

        elif op == '6':
            admin.relocate_doctor_to_patient(patients,doctors)   

        elif op == '7':
            admin.appointment(doctors, patients)    

        elif op == '8':
            admin.patient_management(patients)

        elif op == '9':
            admin.update_details()

        elif op == '10':
            admin.management_report(doctors,patients)

        elif op == '11':
            admin.management_report_diagram(doctors,patients)

        elif op == '0':
            # 6 - Quit
            #ToDo5
            print("You have quit the system.")
            running = False

        else:
            print('Invalid option. Try again')

if __name__ == '__main__':
    main()
