from Person import Person
class Patient(Person):
    """Patient class"""

    def __init__(self, first_name, surname, age, mobile, postcode, symptoms,  illness_type):
        super().__init__(first_name, surname)
        """
        Args:
            first_name (string): First name
            surname (string): Surname
            age (int): Age
            mobile (string): the mobile number
            address (string): address
        """

        self.__age = age
        self.__mobile = mobile
        self.__postcode = postcode
        self.__doctor = 'None'
        self.__symptoms = symptoms
        self.__illness_type = illness_type
       

    
    def full_name(self) :
        """full name is first_name and surname"""
        #ToDo2  
        return f'{self.get_first_name()} {self.get_surname()}'

    def get_age(self) :
        return self.__age
    
    def get_mobile(self) :
        return self.__mobile
    
    def get_post_code(self) :
        return self.__postcode
    
    def get_doctor(self) :
        return self.__doctor
    
    def get_illness_type(self) :
        return self.__illness_type

    def link(self, doctor):
        """Args: doctor(string): the doctor full name"""
        self.__doctor = doctor
 
    def print_symptoms(self):
        """prints all the symptoms"""
        if self.__symptoms:
            print(f"Symptoms for {self.full_name()}:")
            print(f"{self.__symptoms}")
        else:
            print(f"{self.full_name()} has no symptoms recorded.")

    def get_symptoms(self):
        return self.__symptoms
    
    def __str__(self):
        return f'{self.full_name():^30}|{self.__doctor:^30}|{self.__age:^5}|{self.__mobile:^15}|{self.__postcode:^10}'
