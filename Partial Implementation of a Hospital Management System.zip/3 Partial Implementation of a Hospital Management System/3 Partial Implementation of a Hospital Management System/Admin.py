from Doctor import Doctor
from Patient import Patient
import matplotlib.pyplot as plt

class Admin:    
    """A class that deals with the Admin operations"""
    def __init__(self, username, password, address = ''):
        """
        Args:
            username (string): Username
            password (string): Password
            address (string, optional): Address Defaults to ''
        """

        self.__username = username
        self.__password = password
        self.__address =  address
        self.patients = []


    def view(self,a_list):
        """
        print a list
        Args:
            a_list (list): a list of printables
        """
        for index, item in enumerate(a_list):
            print(f'{index+1:3}|{item}')


    def login(self):
        """
        A method that deals with the login
        Raises:
            Exception: returned when the username and the password ...
                    ... don`t match the data registered
        Returns:
            string: the username
        """
    
        print("-----Login-----")
        #Get the details of the admin
        while True:  # Loop to allow multiple login attempts
            username = input("Enter the username: ").strip()
            password = input("Enter the password: ").strip()

            try:
                with open("login.txt", "r") as f:
                    # Read the username and password from the file
                    lines = f.readlines()
                    self.__username = lines[0].strip()
                    self.__password = lines[1].strip()
                    self.__address = lines[2].strip()
            
                    # Check if the input matches the stored credentials
                    if username == self.__username and password == self.__password:
                        print("Successfully logged in the system.")
                        return username  # Exit loop on successful login
                    else:
                        print("Invalid username or password. Please try again.")
                        continue

            except Exception as e:
                print(f"An unexpected error occurred: {e}")
                break  # Exit loop on unexpected errors

    def find_index(self,index,doctors):
        
            # check that the doctor id exists          
        if index in range(0,len(doctors)):
            
            return True

        # if the id is not in the list of doctors
        else:
            return False
            

    def get_doctor_details(self) :
        """
        Get the details needed to add a doctor
        Returns:
            first name, surname and ...
                            ... the speciality of the doctor in that order.
        """
        #ToDo2
        first_name = input("Enter the first name of the Doctor: ")
        surname = input("Enter the surname of the Doctor: ")
        speciality = input("Enter the speciality of the Doctor: ")

        return first_name, surname, speciality


    def doctor_management(self, doctors):
        """
        A method that deals with registering, viewing, updating, deleting doctors
        Args:
            doctors (list<Doctor>): the list of all the doctors names
        """

        print("-----Doctor Management-----")

        # menu
        while True:
            print('Choose the operation:')
            print(' 1 - Register')
            print(' 2 - View')
            print(' 3 - Update')
            print(' 4 - Delete')
            print(' 5 - Return to menu')

            #ToDo3
            while True:
                try:
                    op = input('Input your choice: ')
                    break
                except ValueError:
                    print('The choice entered is incorrect. Try again!')


            # register
            if op == '1':
                print("-----Register-----")

                # get the doctor details
                print('Enter the doctor\'s details:')
                #ToDo4
                first_name,surname,speciality = self.get_doctor_details()

                # check if the name is already registered
                name_exists = False
                for doctor in doctors:
                    if first_name.strip() == doctor.get_first_name() and surname.strip() == doctor.get_surname():
                        print('Name already exists.')
                        name_exists = True
                        #ToDo5
                        break # save time and end the loop

                    #ToDo6
                if not name_exists: 
                    new_doctor = Doctor(first_name, surname, speciality)  
                    doctors.append(new_doctor)                                       # ... to the list of doctors
                    print('Doctor registered.')

            # View
            elif op == '2':
                print("-----List of Doctors-----")
                #ToDo7
                print('ID |          Full name           |  Speciality')
                self.view(doctors)

            # Update
            elif op == '3':
                while True:
                    print("-----Update Doctor`s Details-----")
                    print('ID |          Full name           |  Speciality')
                    self.view(doctors)
                    try:
                        index = int(input('Enter the ID of the doctor: ')) - 1
                        # doctor_index is the ID mines one (-1)
                        doctor_index=self.find_index(index,doctors)
                        if doctor_index!=False:
                    
                            break
                            
                        else:
                            print("Doctor not found")

                        
                                          

                    except ValueError: # the entered id could not be changed into an int
                        print('The ID entered is incorrect')

                # menu
                print('Choose the field to be updated:')
                print(' 1 First name')
                print(' 2 Surname')
                print(' 3 Speciality')
                op = int(input('Input: ')) # make the user input lowercase

                #ToDo8
                
                if op == 1:
                    new_first_name = input("Enter new first name: ")
                    doctors[index].set_first_name(new_first_name)
                elif op == 2:
                    new_surname = input("Enter new surname: ")
                    doctors[index].set_surname(new_surname)
                elif op == 3:
                    new_speciality = input("Enter new speciality: ")
                    doctors[index].set_speciality(new_speciality)

            # Delete
            elif op == '4':
                while True:
                    print("-----Delete Doctor-----")
                    print('ID |          Full Name           |  Speciality')
                    self.view(doctors)

                    try:
                        index = int(input('Enter the ID of the doctor to be deleted: ')) - 1
                        doctor_index = self.find_index(index, doctors)  # Check if doctor exists

                        if doctor_index != False:
                            doctors.pop(index)  # Delete doctor using the correct index
                            print("Doctor deleted successfully.")
                            break  # Exit loop after deletion
                        else:
                            print("Doctor not found. Please enter a valid ID.")

                    except IndexError:
                        print('The ID entered is incorrect.')
            elif op == '5':
                break

            # if the id is not in the list of patients
            else:
                print('Invalid operation choosen. Check your spelling!')


    def view_patient(self, patients):
        """
        print a list of patients
        Args:
            patients (list<Patients>): list of all the active patients
        """
        print("-----View Patients-----")
        print('ID |          Full Name           |      Doctor`s Full Name      | Age |    Mobile     | Postcode ')
        #ToDo10
        self.view(patients)


    def assign_doctor_to_patient(self, patients, doctors):
        """
        Allow the admin to assign a doctor to a patient
        Args:
            patients (list<Patients>): the list of all the active patients
            doctors (list<Doctor>): the list of all the doctors
        """
        
        print("-----Assign-----")
        while True:
            print("-----Patients-----")
            print('ID |          Full Name           |      Doctor`s Full Name      | Age |    Mobile     | Postcode ')
            self.view(patients)

            patient_index = input('Please enter the patient ID: ')

            try:
                # patient_index is the patient ID mines one (-1)
                patient_index = int(patient_index) -1

                # check if the id is not in the list of patients
                if patient_index in range(len(patients)):
                    break
                else:
                    print('The id entered was not found.')
                     # stop the procedures

            except ValueError: # the entered id could not be changed into an int
                print('The id entered is incorrect')
                 # stop the procedures

        while True:
            print("-----Doctors Select-----")
            print('Select the doctor that fits these symptoms:')
            patients[patient_index].print_symptoms() # print the patient symptoms

            print('--------------------------------------------------')
            print('ID |          Full Name           |  Speciality   ')
            self.view(doctors)
            doctor_index = input('Please enter the doctor ID: ')

            try:
                # doctor_index is the patient ID mines one (-1)
                doctor_index = int(doctor_index) -1

                # check if the id is in the list of doctors
                if self.find_index(doctor_index,doctors)!=False:
                        
                    # link the patients to the doctor and vice versa
                    #ToDo11
                    patients[patient_index].link(doctors[doctor_index].full_name())
                    doctors[doctor_index].add_patient(patients[patient_index])
                    print('The patient is now assign to the doctor.')
                    break
                # if the id is not in the list of doctors
                else:
                    print('The id entered was not found.')

            except ValueError: # the entered id could not be changed into an in
                print('The id entered is incorrect')


    def discharge(self, patients, discharge_patients):
        """
        Allow the admin to discharge a patient when treatment is done
        Args:
            patients (list<Patients>): the list of all the active patients
            discharge_patients (list<Patients>): the list of all the non-active patients
        """
        print("-----Discharge Patient-----")

        patient_index = input('Please enter the patient ID: ')
        
        
        try:
            #ToDo12
            patient_index = int(patient_index) - 1
            discharge_patients.append(patients[patient_index])
            patients.pop(patient_index)
            print("Patient has been discharged sucessfully.")

        except IndexError:
            print("Enter correct ID.")


    def view_discharge(self, discharged_patients):
        """
        Prints the list of all discharged patients
        Args:
            discharge_patients (list<Patients>): the list of all the non-active patients
        """

        print("-----Discharged Patients-----")
        print('ID |          Full Name           |      Doctor`s Full Name      | Age |    Mobile     | Postcode')
        #ToDo13
        self.view(discharged_patients)


    def update_credentials(self, line_number: int, new_value: str):
        """Updates the specified line in the credentials file."""
        file_path = "login.txt"
        
        try:
            with open(file_path, 'r') as f:
                lines = f.readlines()
            
            if line_number < len(lines):
                lines[line_number] = new_value.strip() + '\n'
            else:
                print("Error: Line number out of range.")
                return
            
            with open(file_path, 'w') as f:
                f.writelines(lines)
            
            print("Update successful.")
        except FileNotFoundError:
            print("Error: Credentials file not found.")
        except Exception as e:
            print(f"An error occurred: {e}")


    def update_details(self):
        """
        Allows the user to update and change username, password and address
        """

        print('Choose the field to be updated:')
        print(' 1 Username')
        print(' 2 Password')
        print(' 3 Address')
        try:
            op = int(input('Input: '))

            if op == 1:
                #ToDo14
                new_username = input("Enter new admin username: ")
                self.update_credentials(0, new_username)

            elif op == 2:
                password = input('Enter the new password: ')
                # Validate the password
                confirm_password = input('Enter the new password again: ')
                if password == confirm_password:
                    self.update_credentials(1, password)  # Pass the password directly
                else:
                    print("Passwords do not match.")


            elif op == 3:
                #ToDo15
                new_address = input("Enter new admin address: ")
                self.update_credentials(2, new_address)

            else:
                #ToDo16
                print("Enter the correct field to be updated.")

        except ValueError:
            print("Invalid input. Choose correct field.")


    def group_patients_by_family(self, patients):
        families = {}

        for patient in patients:
            if patient.get_surname() not in families:
                families[patient.get_surname()] = []  # Initialize the family list
            families[patient.get_surname()].append(patient)

        for family, members in families.items():
            print(f"Family: {family}")
            for member in members:
                print(f"{member}")


    def appointment(self, doctors, patients):
        while True:
            print('-----Appointment-----')
            print(' 1 - Shedule appointment')
            print(' 2 - View Appointment History of Doctors')
            print(' 3 - Return to the menu')
            while True:
                try:
                    op = input('Input your choice: ')
                    break
                except ValueError:
                    print('The choice entered is incorrect. Try again!')
            
            if op == '1':
                while True:
                    print("-----Patients-----")
                    print('ID |          Full Name           |      Doctor`s Full Name      | Age |    Mobile     | Postcode ')
                    self.view(patients)
                    
                    patient_index = input('Please enter the patient ID: ')
                    try:
                        # patient_index is the patient ID mines one (-1)
                        patient_index = int(patient_index) -1

                    # check if the id is not in the list of patients
                        if patient_index in range(len(patients)):
                            break
                        else:
                            print('The id entered was not found.')
                             # stop the procedures
                    except ValueError: # the entered id could not be changed into an int
                        print('The id entered is incorrect')
                         # stop the procedures
                
                print("-----Doctors-----")
                self.view(doctors)
                while True:
                    try:
                        index = int(input('Enter the ID of the doctor: ')) - 1
                        doctor_index = self.find_index(index,doctors)
                        if doctor_index!=False:
                            break
                                    
                        else:
                            print("Doctor not found")
                                    # doctor_index is the ID mines one (-1)
                                    
                    except ValueError: # the entered id could not be changed into an int
                                print('The ID entered is incorrect')

                while True:
                    date = input("Enter Date (YYYY-MM-DD): ")
                    time = input("Enter Time (HH:MM): ")

                    if len(date) == 10 and date[4] == '-' and date[7] == '-':
                    # Check if the time is in the correct format (HH:MM)
                        if len(time) == 5 and time[2] == ':':
                            doctors[index].set_appointments(date, time)
                            print(f"Patient {patients[patient_index].full_name()} has Appointment scheduled for Doctor {doctors[doctor_index].full_name()} on {date} at {time}.")
                            break

                    print("Invalid format! Please use YYYY-MM-DD for date and HH:MM for time.")

            elif op == '2':
                for doctor in doctors:
                    appointments = doctor.get_appointments()

                    if not appointments:
                        print(f"No appointments scheduled for Dr. {doctor.full_name()}")
                    else:
                        print(f"Appointments for Dr. {doctor.full_name()} ({doctor.get_speciality()}):")
                        for date, time in appointments.items():
                            for times in time:
                                print(f"Date: {date} | Time: {times}")
            
            elif op == '3':
                break


    def relocate_doctor_to_patient(self, patients, doctors):
        
        print("-----Relocate-----")
        while True:
            print("-----Patients-----")
            print('ID |          Full Name           |      Doctor`s Full Name      | Age |    Mobile     | Postcode ')
            self.view(patients)

            patient_index = input('Please enter the patient ID: ')

            try:
                # patient_index is the patient ID mines one (-1)
                patient_index = int(patient_index) -1

                if patient_index in range(len(patients)):
                    break
                else:
                    print('The id entered was not found.')
                     # stop the procedures

            except ValueError: # the entered id could not be changed into an int
                print('The id entered is incorrect')
                 # stop the procedures

        current_doctor = patients[patient_index].get_doctor()

        while True:
            print("-----Doctors Select-----")
        
            print('--------------------------------------------------')
            print('ID |          Full Name           |  Speciality   ')
            self.view(doctors)
            doctor_index = input('Please enter the doctor ID: ')

            try:
                # doctor_index is the patient ID mines one (-1)
                doctor_index = int(doctor_index) -1

                # check if the id is in the list of doctors
                if self.find_index(doctor_index,doctors)!=False:
                    
                    # If the patient already has a doctor, remove them from the previous doctor's list
                    if current_doctor:
                        for doc in doctors:
                            if doc.full_name() == current_doctor:
                                doc.remove_patient(patients[patient_index])  # Decrease count
                                break
                    # link the patients to the doctor and vice versa
                    
                    patients[patient_index].link(doctors[doctor_index].full_name())
                    doctors[doctor_index].add_patient(patients[patient_index])
                    print('The patient is now relocated to the doctor.')
                    break
                # if the id is not in the list of doctors
                else:
                    print('The id entered was not found.')

            except ValueError: # the entered id could not be changed into an in
                print('The id entered is incorrect')


    def management_report(self, doctors, patients):
        while True:
            print('Choose the operation:')
            print(' 1 - Total number of doctors in the system')
            print(' 2 - Total number of patients per doctor')
            print(' 3 - Total number of appointments per month per doctor')
            print(' 4 - Total number of patients based on the illness type')
            print(' 5 - Return to Main Menu')
            op = int(input("Enter choice: "))

            if op == 1:
                print(f"Total number of doctors in the system: {len(doctors)}")

            elif op == 2:
                for doctor in doctors:
                    num_patients = doctor.get_num_patients()
                    print(f"Dr. {doctor.full_name()} has {num_patients} patients.")

            elif op == 3:
                print("\n----- Appointments Per Month -----")
                for doctor in doctors:
                    print(f"\n{doctor.full_name()}'s Appointments Per Month:")
                
                    appointments_per_month = {} 

                    for date in doctor.get_appointments():
                        month_year = date[:7]
                        
                        if month_year in appointments_per_month:
                            appointments_per_month[month_year] += len(doctor.get_appointments()[date])
                        else:
                            appointments_per_month[month_year] = len(doctor.get_appointments()[date])

                    if appointments_per_month:
                        for month, count in sorted(appointments_per_month.items()):
                            print(f" {month}: {count} appointments")
                    else:
                        print("No appointments scheduled.")
                
            elif op == 4:
                if not patients:  # Check if the patient list is empty
                    print("No record in file!")
                    return

                illness_count = {}  # Dictionary to store illness counts

                # Count occurrences of each illness type
                for patient in patients:
                    illness = patient.get_illness_type()
                    if illness in illness_count:
                        illness_count[illness] += 1
                    else:
                        illness_count[illness] = 1

                # Print the total number of patients for each illness type
                print("=" * 40)
                print(f"{'Illness Type':<20} | {'Total Patients':<10}")
                print("=" * 40)

                for illness, count in illness_count.items():
                    print(f"{illness:<20} | {count:<10}")

                print("=" * 40)


            elif op == 5:
                break
            
            else:
                print("Invalid choice.")


    def save_patients_to_file(self,patients):
        if patients is None:
            patients = self.patients
        with open('patient.txt', 'a') as file:
            for patient in patients:
                line = f"{patient.get_first_name()}, {patient.get_surname()}, {patient.get_age()}, {patient.get_mobile()}, {patient.get_post_code()}, {patient.get_symptoms()}, {patient.get_illness_type()} \n"
                file.write(line)
        print("Patient data stored in file successfully")


    def load_patients(self, patients):
        try:
            with open('patient.txt', 'r') as file:
                patient_list = [line.strip().split(', ') for line in file]
            
            if patient_list:
                # Define the header of the table
                header = f"{'First Name':<15} {'Surname':<15} {'Age':<5} {'Mobile':<15} {'Postcode':<10} {'Symptoms':<20} {'Illness Type':<15}"
                print(header)
                print('-' * len(header))  # Print a separator line
                
                # Print each patient's record in a formatted way
                for record in patient_list:
                    first_name, surname, age, mobile, postcode, symptoms, illness_type = record
                    print(f"{first_name:<15} {surname:<15} {age:<5} {mobile:<15} {postcode:<10} {symptoms:<20} {illness_type:<15}")
                
                print("Patient data has loaded.")
            else:
                print("No record in file!!")
            
            return patient_list
        
        except FileNotFoundError:
            print("File is not found.")
            return []


    def add_patients(self, patients):
        try:
            first_name = input("Enter first name: ")
            surname = input("Enter surname: ")
            age = int(input("Enter age: "))
            mobile = input("Enter phone: ")  
            postcode = input("Enter postcode: ")  
            symptoms = input("Enter symptoms: ")
            illness = input("Enter illness type: ")
        except (ValueError, UnboundLocalError):
            print("Enter proper information.")
            return  

        new_patient = Patient(first_name, surname, age, mobile, postcode, symptoms,illness)
        patients.append(new_patient)
        with open('patient.txt','a') as file:
            file.write(f'{first_name}, {surname}, {age}, {mobile}, {postcode}, {symptoms}, {illness} \n')
        print("Patient added successfully.")


    def patient_management(self, patients):
        while True:
                print('Choose the operation:')
                print(' 1- Save Existing Patients')
                print(' 2- Load Patients')
                print(' 3- Add New Patients')
                print(' 4- Return to Main Menu')
    
                op = input('Enter your choice(1/2/3/4): ')

                if op == '1':
        
                    self.save_patients_to_file(patients)
                    break

                elif op == '2':
                    self.load_patients(patients)
                    break

                elif op == '3':
                    self.add_patients(patients)
                    break

                elif op == '4':
                    break
                    
                else:
                    print('Please enter valid options.')


    def management_report_diagram(self, doctors, patients):
        while True:
            print('Choose the operation:')
            print(' 1 - Total number of doctors in the system')
            print(' 2 - Total number of patients per doctor')
            print(' 3 - Total number of appointments per month per doctor')
            print(' 4 - Total number of patients based on the illness type')
            print(' 5 - Return to main menu')

            op = int(input("Enter choice: "))

            if op == 1:
                total_doctors = len(doctors)
                print(f"Total number of doctors in the system: {total_doctors}")

                if total_doctors == 0:
                    print("No doctors available.")
                    return

                # Pie chart with doctor names
                doctor_names = [doctor.full_name() for doctor in doctors]
                sizes = [1] * total_doctors  # Each doctor gets an equal size in the pie chart

                plt.figure(figsize=(7, 7))
                plt.pie(sizes, labels=doctor_names, autopct='%1.1f%%', startangle=140, colors=plt.cm.Paired.colors)
                plt.title("Total Number of Doctors in the System")
                plt.show()

            elif op == 2:
                doctor_names = []
                patient_counts = []

                for doctor in doctors:
                    doctor_names.append(doctor.full_name())
                    patient_counts.append(doctor.get_num_patients())

                # Bar chart
                plt.figure(figsize=(10, 5))
                plt.bar(doctor_names, patient_counts, color='skyblue')
                plt.xlabel("Doctors")
                plt.ylabel("Number of Patients")
                plt.title("Total Number of Patients Per Doctor")
                plt.xticks(rotation=45)
                plt.show()

            elif op == 3:
                for doctor in doctors:
                    print(f"\n{doctor.full_name()}'s Appointments Per Month:")
                
                    appointments_per_month = {} 

                    for date in doctor.get_appointments():
                        month_year = date[:7]
                        
                        if month_year in appointments_per_month:
                            appointments_per_month[month_year] += len(doctor.get_appointments()[date])
                        else:
                            appointments_per_month[month_year] = len(doctor.get_appointments()[date])

                    if appointments_per_month:
                        # Line chart
                        months = sorted(appointments_per_month.keys())
                        counts = [appointments_per_month[m] for m in months]
                        
                        plt.figure(figsize=(10, 5))
                        plt.plot(months, counts, marker='o', linestyle='-', color='blue')
                        plt.xlabel("Month")
                        plt.ylabel("Number of Appointments")
                        plt.title(f"Appointments Per Month for {doctor.full_name()}")
                        plt.xticks(rotation=45)
                        plt.grid()
                        plt.show()
                    else:
                        print("No appointments scheduled.")

            elif op == 4:
                if not patients:
                    print("No record in file!")
                    return

                illness_count = {}

                for patient in patients:
                    illness = patient.get_illness_type()
                    if illness in illness_count:
                        illness_count[illness] += 1
                    else:
                        illness_count[illness] = 1

                # Pie chart
                labels = list(illness_count.keys())
                sizes = list(illness_count.values())

                plt.figure(figsize=(7, 7))
                plt.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=140, colors=['lightcoral', 'lightblue', 'lightgreen', 'gold'])
                plt.title("Total Number of Patients by Illness Type")
                plt.show()

            elif op == 5:
                break
            
            else:
                print("Invalid choice.")
